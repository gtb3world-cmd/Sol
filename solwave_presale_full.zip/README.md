# solwave

Static presale landing page for SolWave — Founded by John Michael.

## Highlights
- Presale Live — 1 $WAVE = 0.0005 USDT
- Presale end date: 25 Oct 2025
- Telegram: https://t.me/SolWave4

## Deploy to GitHub Pages
1. Create a new repository named `solwave` on GitHub.
2. Upload all files from this folder to the repository root.
3. Commit and push to the `main` branch.
4. In repo Settings → Pages, set the source to: **Deploy from branch** → **main** → **/(root)**.
5. Your site will be available at: `https://<your-username>.github.io/solwave/`

## Local preview
Run a simple local server:
```
python3 -m http.server 8000
# then open http://localhost:8000
```
