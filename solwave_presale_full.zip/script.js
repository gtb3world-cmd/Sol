
document.addEventListener('DOMContentLoaded', function () {
  const btn = document.getElementById('mobileMenuBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  btn && btn.addEventListener('click', () => { mobileMenu.classList.toggle('hidden'); });

  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); if (!mobileMenu.classList.contains('hidden')) mobileMenu.classList.add('hidden'); }
    });
  });

  // Countdown to 25 Oct 2025 00:00:00 UTC (Presale end)
  const countdownTarget = new Date('2025-10-25T00:00:00Z').getTime();
  const daysEl = document.getElementById('days');
  const hoursEl = document.getElementById('hours');
  const minsEl = document.getElementById('minutes');
  const secsEl = document.getElementById('seconds');

  function updateCountdown() {
    const now = new Date().getTime();
    const diff = countdownTarget - now;
    if (diff <= 0) {
      daysEl.textContent = '00'; hoursEl.textContent = '00'; minsEl.textContent = '00'; secsEl.textContent = '00'; clearInterval(countdownInterval); return;
    }
    const d = Math.floor(diff / (1000*60*60*24));
    const h = Math.floor((diff / (1000*60*60)) % 24);
    const m = Math.floor((diff / (1000*60)) % 60);
    const s = Math.floor((diff / 1000) % 60);
    daysEl.textContent = String(d).padStart(2,'0');
    hoursEl.textContent = String(h).padStart(2,'0');
    minsEl.textContent = String(m).padStart(2,'0');
    secsEl.textContent = String(s).padStart(2,'0');

    // add glow class briefly to animate
    [daysEl,hoursEl,minsEl,secsEl].forEach(el=>{
      el.classList.add('glow');
      setTimeout(()=>el.classList.remove('glow'),400);
    });
  }
  updateCountdown();
  const countdownInterval = setInterval(updateCountdown, 1000);

  // Presale dynamic values (editable)
  let sold = 4500000;
  let total = 10000000;
  const soldEl = document.getElementById('soldCount');
  const totalEl = document.getElementById('totalCount');
  const fillEl = document.getElementById('progressFill');

  function updatePresale(soldVal, totalVal) {
    sold = soldVal; total = totalVal;
    const pct = Math.max(0, Math.min(100, (sold/total)*100));
    soldEl.textContent = sold.toLocaleString();
    totalEl.textContent = total.toLocaleString();
    fillEl.style.width = pct + '%';
    // pulse buttons
    document.querySelectorAll('.gradient-hover').forEach(b=>b.classList.add('gradient-pulse'));
    setTimeout(()=>document.querySelectorAll('.gradient-hover').forEach(b=>b.classList.remove('gradient-pulse')), 2600);
  }

  // initial update (animated)
  setTimeout(()=>updatePresale(4500000,10000000), 300);

  const subscribeForm = document.getElementById('subscribeForm');
  subscribeForm && subscribeForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    if (!email) return alert('Please enter a valid email.');
    document.getElementById('subscribeBtn').textContent = 'Subscribed ✓';
    setTimeout(() => { document.getElementById('subscribeBtn').textContent = 'Subscribe'; }, 3000);
  });
});


// Theme toggle (dark/light)
const themeToggle = document.getElementById('themeToggle');
function applyTheme(theme) {
  if (theme === 'light') {
    document.documentElement.classList.add('light');
    localStorage.setItem('theme','light');
  } else {
    document.documentElement.classList.remove('light');
    localStorage.setItem('theme','dark');
  }
}
if (themeToggle) {
  themeToggle.addEventListener('click', () => {
    const current = localStorage.getItem('theme') === 'light' ? 'light' : 'dark';
    applyTheme(current === 'light' ? 'dark' : 'light');
  });
  // apply saved theme
  applyTheme(localStorage.getItem('theme') === 'light' ? 'light' : 'dark');
}

// Live presale sold increment simulation (updates every 8-12 seconds randomly)
(function startLiveSold(){
  const soldEl = document.getElementById('soldCount');
  const totalEl = document.getElementById('totalCount');
  let sold = parseInt(soldEl.textContent.replace(/,/g,''), 10) || 4500000;
  const total = parseInt(totalEl.textContent.replace(/,/g,''), 10) || 10000000;
  setInterval(()=>{
    // increment by random small amount
    const inc = Math.floor(Math.random() * 500) + 100; // 100-600
    sold = Math.min(total, sold + inc);
    document.getElementById('soldCount').textContent = sold.toLocaleString();
    const pct = Math.max(0, Math.min(100, (sold/total)*100));
    document.getElementById('progressFill').style.width = pct + '%';
  }, 9000);
})();
